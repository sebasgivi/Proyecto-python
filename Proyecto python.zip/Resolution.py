class Resolution:

	resx = 100
	resy = 15



